package com.company;

//This class's only purpose is for my own testing of each individual *Demo class
public class Main {

    public static void main(String[] args) {
        SemaphoreDemo.main(args);
        CountDownLatchDemo.main(args);
        MailboxDemo.main(args);
        CyclicBarrierDemo.main(args);
    }

}
